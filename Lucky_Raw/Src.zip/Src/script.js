const spinner = document.querySelector('.spinner');
const startBtn = document.querySelector('.spinner__start-button');
const input = document.querySelector('.spinner__input');
const cancelButton = document.querySelector('.cancel-button');
let count = 0;
let plate = document.querySelector('.spinner__plate');
let items = [...document.getElementsByClassName('spinner__item')];
let isSpinning = false;
let cancelledNumbers = new Set();
let appearedNumbers = [];

input.addEventListener('change', e => {
  if (input.value === '' || +input.value < 1) {
    input.value = 1;
  }
  if (+input.value > input.max) {
    input.value = input.max;
  }
});

startBtn.addEventListener('click', function () {
  if (!isSpinning) {
    randomizeItems();
    isSpinning = true;
    startBtn.disabled = true;
    plate.classList.add('spinner__plate--spin');
    plate.addEventListener('animationend', handleAnimationEnd);
  }
});

cancelButton.addEventListener('click', function () {
  const currentNumber = items[0].textContent;
  cancelNumber(currentNumber);
});

// Kiểm tra xem đã lưu trữ dữ liệu trong localStorage chưa
if (localStorage.getItem('cancelledNumbers')) {
  // Nếu đã có dữ liệu, lấy dữ liệu từ localStorage
  cancelledNumbers = new Set(JSON.parse(localStorage.getItem('cancelledNumbers')));
}

function randomizeItems() {
  items.forEach(item => {
    if (!cancelledNumbers.has(item.textContent)) {
      const rand = getRandomNumber();
      item.textContent = rand;
      appearedNumbers.push(rand);
    }
  });
}

function getRandomNumber() {
  const maxNumber = +input.value;
  let randomNumber = random(1, maxNumber);
  while (appearedNumbers.includes(randomNumber)) {
    randomNumber = random(1, maxNumber);
  }
  return randomNumber;
}

function random(min, max) {
  let rand = min - 0.5 + Math.random() * (max - min + 1);
  return Math.round(rand);
}

function handleAnimationEnd() {
  plate.classList.remove('spinner__plate--spin');
  isSpinning = false;
  startBtn.disabled = false;
  plate.removeEventListener('animationend', handleAnimationEnd);
  const currentNumber = items[0].textContent;
  if (!cancelledNumbers.has(currentNumber)) {
    count++;
    addToLog(count, currentNumber);
  }
}

function addToLog(count, number) {
  const logTable = document.getElementById('logTable');
  const tbody = logTable.querySelector('tbody');

  // Kiểm tra xem số đã tồn tại trong danh sách đã hủy chưa
  if (cancelledNumbers.has(number)) {
    return; // Bỏ qua việc thêm số vào bảng log
  }

  // Thêm số vào bảng log
  const newRow = document.createElement('tr');
  const countCell = document.createElement('td');
  const numberCell = document.createElement('td');

  countCell.textContent = count;
  numberCell.textContent = number;

  newRow.appendChild(countCell);
  newRow.appendChild(numberCell);
  tbody.appendChild(newRow);

  // Tạo mới mảng appearedNumbers từ các số đã xuất hiện trong bảng log
  appearedNumbers = Array.from(new Set([...appearedNumbers, number]));

  // Cập nhật STT của bảng log
  updateSTT(logTable);

  // Lưu trữ danh sách các số đã xuất hiện vào localStorage
  localStorage.setItem('appearedNumbers', JSON.stringify(appearedNumbers));
}

function cancelNumber(number) {
  items.forEach(item => {
    if (item.textContent === number) {
      item.textContent = '';
      cancelledNumbers.add(number);
    }
  });

  const logTable = document.getElementById('logTable');
  const tbody = logTable.querySelector('tbody');
  const rows = tbody.querySelectorAll('tr');

  rows.forEach(row => {
    const numberCell = row.querySelector('td:nth-child(2)');
    if (numberCell.textContent === number) {
      row.remove();
    }
  });

  // Cập nhật STT của bảng log
  updateSTT(logTable);

  // Cập nhật danh sách các số đã hủy trong localStorage
  localStorage.setItem('cancelledNumbers', JSON.stringify(Array.from(cancelledNumbers)));
}

function updateSTT(logTable) {
  const tbody = logTable.querySelector('tbody');
  const rows = tbody.querySelectorAll('tr');
  rows.forEach((row, index) => {
    const countCell = row.querySelector('td:nth-child(1)');
    countCell.textContent = index + 1;
  });
}

// Kiểm tra xem đã lưu trữ danh sách các số đã xuất hiện trong localStorage chưa
if (localStorage.getItem('appearedNumbers')) {
  appearedNumbers = JSON.parse(localStorage.getItem('appearedNumbers'));
}
